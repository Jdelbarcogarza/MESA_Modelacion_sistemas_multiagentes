
from ejemplo2_add_space.main import basic_example_space
from M1_Actividad.main import cleaner_robot_activity

if __name__ == "__main__":
    # basic_example()
    # basic_example_space()
    cleaner_robot_activity()
